<iframe src="post.php" width="100%" height="100%" style="border:1px solid black;">
</iframe>
